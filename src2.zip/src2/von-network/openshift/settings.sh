export PROJECT_NAMESPACE="ca7f8f"
export GIT_URI="https://github.com/bcgov/von-network.git"
