# Using the Scripts

Refer to [Indy-Cli Container Environment](../README.md#indy-cli-container-environment) for more details and links to full examples.

Additionally, each of the batch scripts contains usage information containing a description of it's purpose and expected parameters.