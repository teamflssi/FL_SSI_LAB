import grpc
from concurrent import futures
import time
import csv
import os
import functions_pb2
import functions_pb2_grpc
import functions
import signal
import threading

class FederatedAppServicer(functions_pb2_grpc.FederatedAppServicer):

    def ShareModel(self, request, context):
        response = functions_pb2.Empty()
        response.value = functions.ShareModel(request.model)
        return response

    def Train(self, request, context):
        response = functions_pb2.Model()
        response.model = functions.Train()
        return response
    
    def SplitData(self, request, context):
       response = functions_pb2.DataRequest()        
       response.nodenumber = functions.SplitData(request.nodenumber)
       return response







server = grpc.server(futures.ThreadPoolExecutor(max_workers=10))
functions_pb2_grpc.add_FederatedAppServicer_to_server(FederatedAppServicer(), server)
server.add_insecure_port('[::]:50051')
print("Starting server on PORT: 50051")
try:
    server.start()
    server.wait_for_termination()    
except Exception as e:
    print(e)

try:
    while True:
        time.sleep(100)
except KeyboardInterrupt:
    server.stop(0)






