from sklearn.tree import DecisionTreeClassifier
import numpy as np
import numpy as np
import pandas as pd
from load import *
import base64
from scipy import stats
from sklearn.preprocessing import StandardScaler
from sklearn.model_selection import KFold
import random
#import cv2
import os
import csv
#from imutils import paths
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import LabelBinarizer
from sklearn.model_selection import train_test_split
from sklearn.utils import shuffle
from sklearn.metrics import accuracy_score
# Importing necessary libraries
import dill as pickle
import builtins
import matplotlib.pyplot as plt
import seaborn as sns

from sklearn.preprocessing import LabelEncoder, StandardScaler
from sklearn.model_selection import train_test_split
from sklearn.ensemble import RandomForestClassifier
from sklearn.metrics import confusion_matrix, classification_report

#%matplotlib inline
import warnings
warnings.simplefilter(action='ignore', category=FutureWarning)
import tensorflow as tf
import gc
from sklearn import model_selection
from sklearn.model_selection import StratifiedKFold,cross_val_score
from sklearn.svm import SVC
from imblearn.over_sampling import RandomOverSampler
from pandas.io.formats.format import DataFrameFormatter
from imblearn.under_sampling import RandomUnderSampler
from pandas.io.formats.format import DataFrameFormatter
from sklearn.preprocessing import StandardScaler



def init():
    
    model = DecisionTreeClassifier(criterion='gini')
    print("Model succefully init")
    
    return model
    
def agregateDataSource(data_directory):

    # Get a list of all CSV files in the directory
    csv_files = os.listdir(data_directory)
    csv_files = [os.path.join(data_directory, file) for file in csv_files if file.endswith('.csv')]

    # Initialize an empty list to store DataFrames
    dfs = []

    # Loop through the list of CSV files, read each file, and append the DataFrames to the list
    for file in csv_files:
        df = pd.read_csv(file)
        dfs.append(df)

        # Concatenate the list of DataFrames into one DataFrame
        combined_df = pd.concat(dfs, ignore_index=True) 
        print("Agregate is ok")
    return combined_df



    
def setData(df):
    
        
    classes = {
        'DDoS-RSTFINFlood': 'DDoS', 'DDoS-PSHACK_Flood': 'DDoS', 'DDoS-SYN_Flood': 'DDoS',
        'DDoS-UDP_Flood': 'DDoS', 'DDoS-TCP_Flood': 'DDoS', 'DDoS-ICMP_Flood': 'DDoS',
        'DDoS-SynonymousIP_Flood': 'DDoS', 'DDoS-ACK_Fragmentation': 'DDoS',
        'DDoS-UDP_Fragmentation': 'DDoS', 'DDoS-ICMP_Fragmentation': 'DDoS',
        'DDoS-SlowLoris': 'DDoS', 'DDoS-HTTP_Flood': 'DDoS',
        'DoS-UDP_Flood': 'DoS', 'DoS-SYN_Flood': 'DoS', 'DoS-TCP_Flood': 'DoS', 'DoS-HTTP_Flood': 'DoS',
        'Mirai-greeth_flood': 'Mirai', 'Mirai-greip_flood': 'Mirai', 'Mirai-udpplain': 'Mirai',
        'Recon-PingSweep': 'Recon', 'Recon-OSScan': 'Recon', 'Recon-PortScan': 'Recon',
        'VulnerabilityScan': 'Recon', 'Recon-HostDiscovery': 'Recon',
        'DNS_Spoofing': 'Spoofing', 'MITM-ArpSpoofing': 'Spoofing',
        'BenignTraffic': 'Benign',
        'BrowserHijacking': 'Web', 'Backdoor_Malware': 'Web', 'XSS': 'Web',
        'Uploading_Attack': 'Web', 'SqlInjection': 'Web', 'CommandInjection': 'Web',
        'DictionaryBruteForce': 'Brute'  # Add a default label for missing values
    }

    # Add a new column 'sub_label' based on the mapping
    df['sub_label'] = df['label'].map(classes)

    features_not_import=['flow_duration', 'Duration', 'Rate',
        'Srate', 'Drate', 'fin_flag_number',
        'rst_flag_number', 'psh_flag_number',
        'ece_flag_number', 'cwr_flag_number',
        'urg_count',  'HTTP',  'DNS', 'Telnet',
        'SMTP',  'IRC',   'DHCP', 'ARP',  'IPv', 'LLC',
        'Tot sum',  'Max',  'Std',
            'Covariance','syn_flag_number', 'ack_flag_number',
        'ack_count', 'syn_count', 'fin_count', 'HTTPS',
        'TCP', 'UDP']


    df.drop(features_not_import, axis=1,inplace=True)


    from sklearn.preprocessing import LabelEncoder
    # Label Encoding the target columns
    le = LabelEncoder()
    df['sub_label'] = le.fit_transform(df['sub_label'])

    X=df.drop(['label','sub_label'],axis=1)
    y=df['sub_label']


    from imblearn.under_sampling import RandomUnderSampler
   # samp_strat= { 0 : 21257, 1 : 248, 2 :156015, 3 : 156015, 4:51397, 5: 6861, 6: 9453, 7:510}
    samp_strat= { 0 : 55859, 1 : 656, 2 :255859, 3 : 255859, 4:133220, 5: 17985, 6: 24760, 7:1186}
    
    #random_under= RandomUnderSampler(sampling_strategy=samp_strat,random_state=1)
    random_under= RandomUnderSampler(random_state=42)
    X,y = random_under.fit_resample(X,y)
  

    from imblearn.over_sampling import RandomOverSampler
    samp_strat= { 0 : 156015, 1 : 156015, 2 :156015, 3 : 156015, 4:156015, 5: 156015, 6: 156015, 7:156015}
   # random_over= RandomOverSampler(sampling_strategy=samp_strat,random_state=1)
    random_over= RandomOverSampler(random_state=42)
    X,y = random_over.fit_resample(X,y)

    df = pd.concat([X, y] , axis=1)
    df = df.sample(frac = 1)



    X=df.drop(['sub_label'],axis=1)
    y=df['sub_label']
    
    
    
    X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42, shuffle=True, stratify=y)
    from keras.utils import to_categorical
    y_cat = to_categorical(y_train,8)
        


    trim_percentage = 10  # You can adjust this percentage as needed
    kf = KFold(n_splits=5, shuffle=True, random_state=7)

    sc = StandardScaler()

    # Assuming X_train and y_cat are defined and contain your data
    # Normalize input data
    X_train = sc.fit_transform(X_train)


    return X_train, X_test, y_train, y_test,sc,kf,y_cat