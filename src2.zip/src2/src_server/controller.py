import grpc
import base64
import pandas as pd
import os
from load import *
import functions_pb2
import functions_pb2_grpc
from sklearn.metrics import confusion_matrix
from sklearn.metrics import accuracy_score
import concurrent.futures
import numpy as np
import dill as pickle
from sklearn.ensemble import VotingClassifier
#import pickle
from sklearn.base import BaseEstimator, ClassifierMixin
import warnings  
with warnings.catch_warnings():
    warnings.filterwarnings("ignore",category=FutureWarning)
    from keras.models import load_model

from sklearn.metrics import confusion_matrix, classification_report


def encode_file(file_name):
    with pd.read_csv('Models/'+file_name) as file:
        encoded_string = base64.b64encode(file.read())
    return encoded_string

#declare channels here.
#channel<n> is the channel for node 'n'
channel01 = grpc.insecure_channel('173.17.0.150:50051')
channel02 = grpc.insecure_channel('173.17.0.151:50051')


#declare stubs here
#stub<n> is the stub for channel<n>
stub01 = functions_pb2_grpc.FederatedAppStub(channel01)
stub02 = functions_pb2_grpc.FederatedAppStub(channel02)



# array of all our stubs
stubs = [
    stub01,
    stub02               
]

#number of nodes on the network
n = len(stubs)

"""Util functions"""



def shareFunc(i, opt):
    if (opt == 2):
        filename = "InitModel.pkl"
    else :
        filename = "optimized_model.pkl"
    ModelString = functions_pb2.Model(model=encode_file(filename))
    res = stubs[i].shareModel(ModelString)
    print("node0",i+1,":",res.value, " - file :", filename)


def trainFunc(i):
    empty = functions_pb2.Empty(value = 1)
    res = stubs[i].Train(empty)
    with open("Models/model_"+str(i+1)+".pkl","wb") as file:
        file.write(base64.b64decode(res.model))
    print("Saved model from node0",i)
    
    
def sendNodeNumber(i):   
    try:
        NodeNumber = functions_pb2.DataRequest(nodenumber=int(i))
        res = stubs[i].SplitData(NodeNumber)
        print("node0",i+1,":",res.value)
    except:
        print("")

""" Option handlers here """


def shareModel(opt):

    executor = concurrent.futures.ProcessPoolExecutor(n)
    futures = [executor.submit(shareFunc, i, opt) for i in range(n)]
    concurrent.futures.wait(futures)
    
def train():

    executor = concurrent.futures.ProcessPoolExecutor(n)
    futures = [executor.submit(trainFunc, i) for i in range(n)]
    concurrent.futures.wait(futures)

def optimiseModels():
        
    models_directory = 'Models'
    data_directory = 'DatasetSource'
    combined_df = agregateDataSource(data_directory)
    X_train, X_test, y_train, y_test,sc,kf,y_cat = setData(combined_df)
    # Get a list of all pkl files in the directory
    local_model_files = os.listdir(models_directory )
    local_model_files = [os.path.join(models_directory , file) for file in local_model_files if file.endswith('.pkl')]

    # Load the local models from the .pkl files
    local_models = []
    for file in local_model_files:
        with open(file, 'rb') as f:
            local_model = pickle.load(f)
            local_models.append(local_model)

    
    # Combine the models in the list into a single model
    estimators = [(f'model{i}', model) for i, model in enumerate(local_models)]
    ensemble = VotingClassifier(estimators=estimators, voting='hard')
    # Fit the VotingClassifier
    ensemble.fit(X_train, y_train,sample_weight=None)
    # Save the new global model in a .pkl file
    with open('FinalModel/optimized_model.pkl', 'wb') as f:
        pickle.dump(ensemble, f)

    print("Averaged over all models - optimized model saved!")







def nodeNumber():
    executor = concurrent.futures.ProcessPoolExecutor(n)
    futures = [executor.submit(sendNodeNumber, i) for i in range(n)]
    concurrent.futures.wait(futures)
    
    

def printResults():

    # Define the file path
    directory_path= 'FinalModel'  
    files_in_directory = os.listdir(directory_path)
    file_name='optimized_model.pkl'
    data_directory = 'DatasetSource'
    df = agregateDataSource(data_directory)
    X_train, X_test, y_train, y_test,sc,kf,y_cat = setData(df)
   
    if file_name in files_in_directory:
        with open('FinalModel/optimized_model.pkl', 'rb') as file: model = pickle.load(file) 
        
    X_test = sc.transform(X_test)   
    # test le model
    #model.fit(X_train,y_train)
    y_pred=model.predict(X_test) #y_pred : la prediction 
    y_pred = y_pred.reshape(-1, 1)
    Y_pred = np.argmax(y_pred,axis=1)  
     

    cm = confusion_matrix(y_test, Y_pred)  # comparer y_pred avec y_test
    print(cm)
    print("Final Accuracy: %.2f%%"% (accuracy_score(y_test, Y_pred) * 100))     
   # print((model.score(X_test, y_test))* 100)
   
    labels = ['Benign', 'Brute', 'DDoS', 'DoS','Mirai','Recon','Spoofing','Web']
    cm = confusion_matrix(y_test, Y_pred)
    thresh = cm.max() / 2.

    fig, ax = plt.subplots(figsize=(10,6))
    im, cbar = heatmap(cm, labels, labels, ax=ax,
                        cmap=plt.cm.Blues, cbarlabel="count of predictions")
    texts = annotate_heatmap(im, data=cm, threshold=thresh)
    plt.xlabel('Predicted Traffic Type')
    plt.ylabel('Actual Traffic Type')
    plt.title('Confusion Matrix for Federated Learning with Decision Tree');

    fig.tight_layout()
    plt.savefig("sample.jpg",dpi=300)
    plt.show()            

    print(classification_report(y_test, Y_pred,target_names=labels))
    
    
    
    

def heatmap(data, row_labels, col_labels, ax=None, cbar_kw={}, cbarlabel="", **kwargs):
    """
    Create a heatmap from a numpy array and two lists of labels.
    """
    if not ax:
        ax = plt.gca()

    # Plot the heatmap
    im = ax.imshow(data, **kwargs)

    # Create colorbar
    cbar = ax.figure.colorbar(im, ax=ax, **cbar_kw)
    cbar.ax.set_ylabel(cbarlabel, rotation=-90, va="bottom")

    # Let the horizontal axes labeling appear on top.
    ax.tick_params(top=True, bottom=False,
                   labeltop=True, labelbottom=False)
    # We want to show all ticks...
    ax.set_xticks(np.arange(data.shape[1]))
    ax.set_yticks(np.arange(data.shape[0]))
    # ... and label them with the respective list entries.
    ax.set_xticklabels(col_labels)
    ax.set_yticklabels(row_labels)

    ax.set_xlabel('Predicted Label')
    ax.set_ylabel('True Label')

    return im, cbar

def annotate_heatmap(im, data=None, fmt="d", threshold=None):
    """
    A function to annotate a heatmap.
    """
    # Change the text's color depending on the data.
    thresh =threshold 
    texts = []
    for i in range(data.shape[0]):
        for j in range(data.shape[1]):
            text = im.axes.text(j, i, format(data[i, j], fmt), horizontalalignment="center",
                                 color="white" if data[i, j] > thresh else "black")
            texts.append(text)

    return texts       
     
     
      

            
# Finding the classification report






# Function for plotting the ROC curve

import matplotlib.pyplot as plt
from sklearn.preprocessing import LabelBinarizer
from sklearn.metrics import roc_curve, auc, roc_auc_score

target = ['Benign', 'Brute', 'DDoS', 'DoS','Mirai','Recon','Spoofing','Web']

fig, c_ax = plt.subplots(1,1, figsize = (12, 8))

# function for scoring roc auc score for multi-class
def multiclass_roc_auc_score(y_test, y_pred, average="macro"):
    lb = LabelBinarizer()
    lb.fit(y_test)
    y_test = lb.transform(y_test)
    y_pred = lb.transform(y_pred)

    for (idx, c_label) in enumerate(target):
        fpr, tpr, thresholds = roc_curve(y_test[:,idx].astype(int), y_pred[:,idx])
        print(fpr,tpr)
        c_ax.plot(fpr, tpr, label = '%s (AUC:%0.2f)'  % (c_label, auc(fpr, tpr)))
    c_ax.plot(fpr, fpr, 'b-', label = 'Random Guessing')
    return roc_auc_score(y_test, y_pred, average=average)

def printRoc(y_test, Y_pred):
    print('ROC AUC score:', multiclass_roc_auc_score(y_test, Y_pred))

    c_ax.legend()
    c_ax.set_xlabel('False Positive Rate', fontsize=25)
    c_ax.set_ylabel('True Positive Rate',fontsize=25)
    plt.savefig('ROC_LSTM',dpi=300)
    plt.show()










                  
            # Train the model
        #model.predict(X_test, y_test)
         
  

while True:
        print("1. Split Data and Initialize model on all nodes")
        print("2. Perform training on all nodes")
        print("3. Generate new optimized model")
        print("4. Print results")
        print("5. Exit")
        print("Enter an option: ")
        option = input()
        
        if (option == "1"):
            try:
              nodeNumber()
            except Exception as e:
             print(e)         
        if (option == "2"):
            try:
             train()
            except Exception as e:
             print(e)
        if (option == "3"):
            try:
              optimiseModels()
            except Exception as e:
             print(e)         
        if (option == "4"):
            try:
              printResults()
            except Exception as e:
             print(e)
