#!/bin/bash

PORTS="8003 11003" ./run_docker start --label Nurse -it http 0.0.0.0 8003 -ot http --admin 0.0.0.0 11003 --admin-insecure-mode --endpoint http://172.17.01:8003/ --genesis-url http://172.17.01:9000/genesis --debug-connections --auto-provision --wallet-local-did --wallet-type indy --wallet-name NurseWallet --log-level 'info' --auto-provision --auto-accept-invites --auto-accept-requests --auto-ping-connection --tails-server-base-url http://172.17.01:6543 --wallet-key secret

