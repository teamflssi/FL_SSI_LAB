#!/bin/bash

PORTS="8000 11000" ./run_docker start --label patient -it http 0.0.0.0 8000 -ot http --admin 0.0.0.0 11000 --admin-insecure-mode --genesis-url http://172.17.01:9000/genesis --seed EmatiSaidi0000000000000000002022 --endpoint http://172.17.01:8000/ --debug-connections --auto-provision --wallet-type indy --log-level 'info' --auto-provision --auto-accept-invites --auto-accept-requests --auto-ping-connection --tails-server-base-url http://172.17.01:6543 --wallet-name thePatientWallet --wallet-key secret



