#!/bin/bash

PORTS="8004 11004" ./run_docker start --label Hospital -it http 0.0.0.0 8004 -ot http --admin 0.0.0.0 11004 --admin-insecure-mode --endpoint http://172.17.01:8004/ --genesis-url http://172.17.01:9000/genesis --debug-connections --auto-provision --wallet-local-did --wallet-type indy --wallet-name MyHospitalWallet --log-level 'info' --auto-provision --auto-accept-invites --auto-accept-requests --auto-ping-connection --tails-server-base-url http://172.17.01:6543 --wallet-key secret
