#!/bin/bash

PORTS="8002 11002" aca-py start --label Doctor -it http 0.0.0.0 8002 -ot http --admin 0.0.0.0 11002 --admin-insecure-mode --endpoint http://172.17.01:8002/ --genesis-url http://172.17.01:9000/genesis --debug-connections --auto-provision --wallet-local-did --wallet-type indy --wallet-name TheDoctorWallet --log-level 'info' --auto-provision --auto-accept-invites --auto-accept-requests --auto-ping-connection --tails-server-base-url http://172.17.01:6543 --wallet-key secret





