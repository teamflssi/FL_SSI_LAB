"""Library version information."""

__version__ = "0.7.4-rc2"
RECORD_TYPE_ACAPY_VERSION = "acapy_version"
