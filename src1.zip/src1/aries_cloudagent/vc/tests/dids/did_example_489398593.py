DID_EXAMPLE_48939859 = {
    "@context": "https://www.w3.org/ns/did/v1",
    "id": "did:example:489398593",
    "assertionMethod": [
        {
            "id": "did:example:489398593#test",
            "type": "Bls12381G2Key2020",
            "controller": "did:example:489398593",
            "publicKeyBase58": "oqpWYKaZD9M1Kbe94BVXpr8WTdFBNZyKv48cziTiQUeuhm7sBhCABMyYG4kcMrseC68YTFFgyhiNeBKjzdKk9MiRWuLv5H4FFujQsQK2KTAtzU8qTBiZqBHMmnLF4PL7Ytu",
        }
    ],
}
