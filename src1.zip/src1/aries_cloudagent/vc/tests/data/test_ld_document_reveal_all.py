TEST_LD_DOCUMENT_REVEAL_ALL = {
    "@context": ["http://schema.org/", "https://w3id.org/security/v3-unstable"],
    "@type": "Person",
}
