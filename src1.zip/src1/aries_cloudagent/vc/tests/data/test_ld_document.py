TEST_LD_DOCUMENT = {
    "@context": ["http://schema.org/", "https://w3id.org/security/bbs/v1"],
    "@type": "Person",
    "firstName": "Jane",
    "lastName": "Does",
    "jobTitle": "Professor",
    "telephone": "(425) 123-4567",
    "email": "jane.doe@example.com",
}
