TEST_LD_DOCUMENT_REVEAL = {
    "@context": ["http://schema.org/", "https://w3id.org/security/bbs/v1"],
    "@type": "Person",
    "@explicit": True,
    "firstName": "Jane",
    "lastName": "Does",
}
