"""Linked data proof exception classes."""


class LinkedDataProofException(Exception):
    """Base exception for linked data proof module."""
