aries\_cloudagent.protocols.revocation\_notification.v1\_0.messages package
===========================================================================

.. automodule:: aries_cloudagent.protocols.revocation_notification.v1_0.messages
   :members:
   :undoc-members:
   :show-inheritance:

Submodules
----------

aries\_cloudagent.protocols.revocation\_notification.v1\_0.messages.revoke module
---------------------------------------------------------------------------------

.. automodule:: aries_cloudagent.protocols.revocation_notification.v1_0.messages.revoke
   :members:
   :undoc-members:
   :show-inheritance:
