aries\_cloudagent.storage.vc\_holder package
============================================

.. automodule:: aries_cloudagent.storage.vc_holder
   :members:
   :undoc-members:
   :show-inheritance:

Submodules
----------

aries\_cloudagent.storage.vc\_holder.askar module
-------------------------------------------------

.. automodule:: aries_cloudagent.storage.vc_holder.askar
   :members:
   :undoc-members:
   :show-inheritance:

aries\_cloudagent.storage.vc\_holder.base module
------------------------------------------------

.. automodule:: aries_cloudagent.storage.vc_holder.base
   :members:
   :undoc-members:
   :show-inheritance:

aries\_cloudagent.storage.vc\_holder.in\_memory module
------------------------------------------------------

.. automodule:: aries_cloudagent.storage.vc_holder.in_memory
   :members:
   :undoc-members:
   :show-inheritance:

aries\_cloudagent.storage.vc\_holder.indy module
------------------------------------------------

.. automodule:: aries_cloudagent.storage.vc_holder.indy
   :members:
   :undoc-members:
   :show-inheritance:

aries\_cloudagent.storage.vc\_holder.vc\_record module
------------------------------------------------------

.. automodule:: aries_cloudagent.storage.vc_holder.vc_record
   :members:
   :undoc-members:
   :show-inheritance:

aries\_cloudagent.storage.vc\_holder.xform module
-------------------------------------------------

.. automodule:: aries_cloudagent.storage.vc_holder.xform
   :members:
   :undoc-members:
   :show-inheritance:
