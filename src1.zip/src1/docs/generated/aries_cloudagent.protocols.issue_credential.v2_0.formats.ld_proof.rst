aries\_cloudagent.protocols.issue\_credential.v2\_0.formats.ld\_proof package
=============================================================================

.. automodule:: aries_cloudagent.protocols.issue_credential.v2_0.formats.ld_proof
   :members:
   :undoc-members:
   :show-inheritance:

Subpackages
-----------

.. toctree::
   :maxdepth: 4

   aries_cloudagent.protocols.issue_credential.v2_0.formats.ld_proof.models

Submodules
----------

aries\_cloudagent.protocols.issue\_credential.v2\_0.formats.ld\_proof.handler module
------------------------------------------------------------------------------------

.. automodule:: aries_cloudagent.protocols.issue_credential.v2_0.formats.ld_proof.handler
   :members:
   :undoc-members:
   :show-inheritance:
