aries\_cloudagent.protocols.problem\_report package
===================================================

.. automodule:: aries_cloudagent.protocols.problem_report
   :members:
   :undoc-members:
   :show-inheritance:

Subpackages
-----------

.. toctree::
   :maxdepth: 4

   aries_cloudagent.protocols.problem_report.v1_0

Submodules
----------

aries\_cloudagent.protocols.problem\_report.definition module
-------------------------------------------------------------

.. automodule:: aries_cloudagent.protocols.problem_report.definition
   :members:
   :undoc-members:
   :show-inheritance:
