aries\_cloudagent.protocols.revocation\_notification.v1\_0.handlers package
===========================================================================

.. automodule:: aries_cloudagent.protocols.revocation_notification.v1_0.handlers
   :members:
   :undoc-members:
   :show-inheritance:

Submodules
----------

aries\_cloudagent.protocols.revocation\_notification.v1\_0.handlers.revoke\_handler module
------------------------------------------------------------------------------------------

.. automodule:: aries_cloudagent.protocols.revocation_notification.v1_0.handlers.revoke_handler
   :members:
   :undoc-members:
   :show-inheritance:
