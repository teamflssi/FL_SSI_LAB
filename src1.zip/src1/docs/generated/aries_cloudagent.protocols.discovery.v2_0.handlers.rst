aries\_cloudagent.protocols.discovery.v2\_0.handlers package
============================================================

.. automodule:: aries_cloudagent.protocols.discovery.v2_0.handlers
   :members:
   :undoc-members:
   :show-inheritance:

Submodules
----------

aries\_cloudagent.protocols.discovery.v2\_0.handlers.disclosures\_handler module
--------------------------------------------------------------------------------

.. automodule:: aries_cloudagent.protocols.discovery.v2_0.handlers.disclosures_handler
   :members:
   :undoc-members:
   :show-inheritance:

aries\_cloudagent.protocols.discovery.v2\_0.handlers.queries\_handler module
----------------------------------------------------------------------------

.. automodule:: aries_cloudagent.protocols.discovery.v2_0.handlers.queries_handler
   :members:
   :undoc-members:
   :show-inheritance:
