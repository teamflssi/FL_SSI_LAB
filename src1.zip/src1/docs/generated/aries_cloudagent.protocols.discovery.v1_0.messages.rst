aries\_cloudagent.protocols.discovery.v1\_0.messages package
============================================================

.. automodule:: aries_cloudagent.protocols.discovery.v1_0.messages
   :members:
   :undoc-members:
   :show-inheritance:

Submodules
----------

aries\_cloudagent.protocols.discovery.v1\_0.messages.disclose module
--------------------------------------------------------------------

.. automodule:: aries_cloudagent.protocols.discovery.v1_0.messages.disclose
   :members:
   :undoc-members:
   :show-inheritance:

aries\_cloudagent.protocols.discovery.v1\_0.messages.query module
-----------------------------------------------------------------

.. automodule:: aries_cloudagent.protocols.discovery.v1_0.messages.query
   :members:
   :undoc-members:
   :show-inheritance:
