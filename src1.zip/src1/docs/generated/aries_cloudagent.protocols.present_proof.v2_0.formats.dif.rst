aries\_cloudagent.protocols.present\_proof.v2\_0.formats.dif package
====================================================================

.. automodule:: aries_cloudagent.protocols.present_proof.v2_0.formats.dif
   :members:
   :undoc-members:
   :show-inheritance:

Submodules
----------

aries\_cloudagent.protocols.present\_proof.v2\_0.formats.dif.handler module
---------------------------------------------------------------------------

.. automodule:: aries_cloudagent.protocols.present_proof.v2_0.formats.dif.handler
   :members:
   :undoc-members:
   :show-inheritance:
