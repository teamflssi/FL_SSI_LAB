aries\_cloudagent.vc.ld\_proofs.purposes package
================================================

.. automodule:: aries_cloudagent.vc.ld_proofs.purposes
   :members:
   :undoc-members:
   :show-inheritance:

Submodules
----------

aries\_cloudagent.vc.ld\_proofs.purposes.assertion\_proof\_purpose module
-------------------------------------------------------------------------

.. automodule:: aries_cloudagent.vc.ld_proofs.purposes.assertion_proof_purpose
   :members:
   :undoc-members:
   :show-inheritance:

aries\_cloudagent.vc.ld\_proofs.purposes.authentication\_proof\_purpose module
------------------------------------------------------------------------------

.. automodule:: aries_cloudagent.vc.ld_proofs.purposes.authentication_proof_purpose
   :members:
   :undoc-members:
   :show-inheritance:

aries\_cloudagent.vc.ld\_proofs.purposes.controller\_proof\_purpose module
--------------------------------------------------------------------------

.. automodule:: aries_cloudagent.vc.ld_proofs.purposes.controller_proof_purpose
   :members:
   :undoc-members:
   :show-inheritance:

aries\_cloudagent.vc.ld\_proofs.purposes.credential\_issuance\_purpose module
-----------------------------------------------------------------------------

.. automodule:: aries_cloudagent.vc.ld_proofs.purposes.credential_issuance_purpose
   :members:
   :undoc-members:
   :show-inheritance:

aries\_cloudagent.vc.ld\_proofs.purposes.proof\_purpose module
--------------------------------------------------------------

.. automodule:: aries_cloudagent.vc.ld_proofs.purposes.proof_purpose
   :members:
   :undoc-members:
   :show-inheritance:
