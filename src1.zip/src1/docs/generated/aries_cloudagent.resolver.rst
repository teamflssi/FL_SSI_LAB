aries\_cloudagent.resolver package
==================================

.. automodule:: aries_cloudagent.resolver
   :members:
   :undoc-members:
   :show-inheritance:

Subpackages
-----------

.. toctree::
   :maxdepth: 4

   aries_cloudagent.resolver.default

Submodules
----------

aries\_cloudagent.resolver.base module
--------------------------------------

.. automodule:: aries_cloudagent.resolver.base
   :members:
   :undoc-members:
   :show-inheritance:

aries\_cloudagent.resolver.did\_resolver module
-----------------------------------------------

.. automodule:: aries_cloudagent.resolver.did_resolver
   :members:
   :undoc-members:
   :show-inheritance:

aries\_cloudagent.resolver.did\_resolver\_registry module
---------------------------------------------------------

.. automodule:: aries_cloudagent.resolver.did_resolver_registry
   :members:
   :undoc-members:
   :show-inheritance:

aries\_cloudagent.resolver.routes module
----------------------------------------

.. automodule:: aries_cloudagent.resolver.routes
   :members:
   :undoc-members:
   :show-inheritance:
