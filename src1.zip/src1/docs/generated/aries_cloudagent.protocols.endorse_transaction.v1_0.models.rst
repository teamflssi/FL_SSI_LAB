aries\_cloudagent.protocols.endorse\_transaction.v1\_0.models package
=====================================================================

.. automodule:: aries_cloudagent.protocols.endorse_transaction.v1_0.models
   :members:
   :undoc-members:
   :show-inheritance:

Submodules
----------

aries\_cloudagent.protocols.endorse\_transaction.v1\_0.models.transaction\_record module
----------------------------------------------------------------------------------------

.. automodule:: aries_cloudagent.protocols.endorse_transaction.v1_0.models.transaction_record
   :members:
   :undoc-members:
   :show-inheritance:
