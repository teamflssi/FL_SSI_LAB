aries\_cloudagent.protocols.issue\_credential.v2\_0.formats package
===================================================================

.. automodule:: aries_cloudagent.protocols.issue_credential.v2_0.formats
   :members:
   :undoc-members:
   :show-inheritance:

Subpackages
-----------

.. toctree::
   :maxdepth: 4

   aries_cloudagent.protocols.issue_credential.v2_0.formats.indy
   aries_cloudagent.protocols.issue_credential.v2_0.formats.ld_proof

Submodules
----------

aries\_cloudagent.protocols.issue\_credential.v2\_0.formats.handler module
--------------------------------------------------------------------------

.. automodule:: aries_cloudagent.protocols.issue_credential.v2_0.formats.handler
   :members:
   :undoc-members:
   :show-inheritance:
