aries\_cloudagent.multitenant package
=====================================

.. automodule:: aries_cloudagent.multitenant
   :members:
   :undoc-members:
   :show-inheritance:

Subpackages
-----------

.. toctree::
   :maxdepth: 4

   aries_cloudagent.multitenant.admin

Submodules
----------

aries\_cloudagent.multitenant.askar\_profile\_manager module
------------------------------------------------------------

.. automodule:: aries_cloudagent.multitenant.askar_profile_manager
   :members:
   :undoc-members:
   :show-inheritance:

aries\_cloudagent.multitenant.base module
-----------------------------------------

.. automodule:: aries_cloudagent.multitenant.base
   :members:
   :undoc-members:
   :show-inheritance:

aries\_cloudagent.multitenant.error module
------------------------------------------

.. automodule:: aries_cloudagent.multitenant.error
   :members:
   :undoc-members:
   :show-inheritance:

aries\_cloudagent.multitenant.manager module
--------------------------------------------

.. automodule:: aries_cloudagent.multitenant.manager
   :members:
   :undoc-members:
   :show-inheritance:

aries\_cloudagent.multitenant.manager\_provider module
------------------------------------------------------

.. automodule:: aries_cloudagent.multitenant.manager_provider
   :members:
   :undoc-members:
   :show-inheritance:
