aries\_cloudagent.protocols.discovery.v2\_0.messages package
============================================================

.. automodule:: aries_cloudagent.protocols.discovery.v2_0.messages
   :members:
   :undoc-members:
   :show-inheritance:

Submodules
----------

aries\_cloudagent.protocols.discovery.v2\_0.messages.disclosures module
-----------------------------------------------------------------------

.. automodule:: aries_cloudagent.protocols.discovery.v2_0.messages.disclosures
   :members:
   :undoc-members:
   :show-inheritance:

aries\_cloudagent.protocols.discovery.v2\_0.messages.queries module
-------------------------------------------------------------------

.. automodule:: aries_cloudagent.protocols.discovery.v2_0.messages.queries
   :members:
   :undoc-members:
   :show-inheritance:
