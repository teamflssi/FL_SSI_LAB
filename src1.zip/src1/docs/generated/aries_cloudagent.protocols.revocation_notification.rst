aries\_cloudagent.protocols.revocation\_notification package
============================================================

.. automodule:: aries_cloudagent.protocols.revocation_notification
   :members:
   :undoc-members:
   :show-inheritance:

Subpackages
-----------

.. toctree::
   :maxdepth: 4

   aries_cloudagent.protocols.revocation_notification.v1_0

Submodules
----------

aries\_cloudagent.protocols.revocation\_notification.definition module
----------------------------------------------------------------------

.. automodule:: aries_cloudagent.protocols.revocation_notification.definition
   :members:
   :undoc-members:
   :show-inheritance:
