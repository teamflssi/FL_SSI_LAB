aries\_cloudagent.holder package
================================

.. automodule:: aries_cloudagent.holder
   :members:
   :undoc-members:
   :show-inheritance:

Submodules
----------

aries\_cloudagent.holder.routes module
--------------------------------------

.. automodule:: aries_cloudagent.holder.routes
   :members:
   :undoc-members:
   :show-inheritance:
