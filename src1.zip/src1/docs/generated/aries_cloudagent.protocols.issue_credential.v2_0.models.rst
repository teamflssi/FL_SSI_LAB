aries\_cloudagent.protocols.issue\_credential.v2\_0.models package
==================================================================

.. automodule:: aries_cloudagent.protocols.issue_credential.v2_0.models
   :members:
   :undoc-members:
   :show-inheritance:

Subpackages
-----------

.. toctree::
   :maxdepth: 4

   aries_cloudagent.protocols.issue_credential.v2_0.models.detail

Submodules
----------

aries\_cloudagent.protocols.issue\_credential.v2\_0.models.cred\_ex\_record module
----------------------------------------------------------------------------------

.. automodule:: aries_cloudagent.protocols.issue_credential.v2_0.models.cred_ex_record
   :members:
   :undoc-members:
   :show-inheritance:
