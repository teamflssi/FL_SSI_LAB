aries\_cloudagent.protocols.issue\_credential.v2\_0.models.detail package
=========================================================================

.. automodule:: aries_cloudagent.protocols.issue_credential.v2_0.models.detail
   :members:
   :undoc-members:
   :show-inheritance:

Submodules
----------

aries\_cloudagent.protocols.issue\_credential.v2\_0.models.detail.indy module
-----------------------------------------------------------------------------

.. automodule:: aries_cloudagent.protocols.issue_credential.v2_0.models.detail.indy
   :members:
   :undoc-members:
   :show-inheritance:

aries\_cloudagent.protocols.issue\_credential.v2\_0.models.detail.ld\_proof module
----------------------------------------------------------------------------------

.. automodule:: aries_cloudagent.protocols.issue_credential.v2_0.models.detail.ld_proof
   :members:
   :undoc-members:
   :show-inheritance:
