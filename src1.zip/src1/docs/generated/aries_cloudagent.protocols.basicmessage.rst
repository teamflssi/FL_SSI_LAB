aries\_cloudagent.protocols.basicmessage package
================================================

.. automodule:: aries_cloudagent.protocols.basicmessage
   :members:
   :undoc-members:
   :show-inheritance:

Subpackages
-----------

.. toctree::
   :maxdepth: 4

   aries_cloudagent.protocols.basicmessage.v1_0

Submodules
----------

aries\_cloudagent.protocols.basicmessage.definition module
----------------------------------------------------------

.. automodule:: aries_cloudagent.protocols.basicmessage.definition
   :members:
   :undoc-members:
   :show-inheritance:
