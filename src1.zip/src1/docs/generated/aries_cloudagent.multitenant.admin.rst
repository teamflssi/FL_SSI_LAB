aries\_cloudagent.multitenant.admin package
===========================================

.. automodule:: aries_cloudagent.multitenant.admin
   :members:
   :undoc-members:
   :show-inheritance:

Submodules
----------

aries\_cloudagent.multitenant.admin.routes module
-------------------------------------------------

.. automodule:: aries_cloudagent.multitenant.admin.routes
   :members:
   :undoc-members:
   :show-inheritance:
