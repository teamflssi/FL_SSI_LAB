aries\_cloudagent.protocols.revocation\_notification.v1\_0.models package
=========================================================================

.. automodule:: aries_cloudagent.protocols.revocation_notification.v1_0.models
   :members:
   :undoc-members:
   :show-inheritance:

Submodules
----------

aries\_cloudagent.protocols.revocation\_notification.v1\_0.models.rev\_notification\_record module
--------------------------------------------------------------------------------------------------

.. automodule:: aries_cloudagent.protocols.revocation_notification.v1_0.models.rev_notification_record
   :members:
   :undoc-members:
   :show-inheritance:
