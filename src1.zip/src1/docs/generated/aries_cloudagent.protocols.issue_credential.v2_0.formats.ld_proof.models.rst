aries\_cloudagent.protocols.issue\_credential.v2\_0.formats.ld\_proof.models package
====================================================================================

.. automodule:: aries_cloudagent.protocols.issue_credential.v2_0.formats.ld_proof.models
   :members:
   :undoc-members:
   :show-inheritance:

Submodules
----------

aries\_cloudagent.protocols.issue\_credential.v2\_0.formats.ld\_proof.models.cred\_detail module
------------------------------------------------------------------------------------------------

.. automodule:: aries_cloudagent.protocols.issue_credential.v2_0.formats.ld_proof.models.cred_detail
   :members:
   :undoc-members:
   :show-inheritance:

aries\_cloudagent.protocols.issue\_credential.v2\_0.formats.ld\_proof.models.cred\_detail\_options module
---------------------------------------------------------------------------------------------------------

.. automodule:: aries_cloudagent.protocols.issue_credential.v2_0.formats.ld_proof.models.cred_detail_options
   :members:
   :undoc-members:
   :show-inheritance:
