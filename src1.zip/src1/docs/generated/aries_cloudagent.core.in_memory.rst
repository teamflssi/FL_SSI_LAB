aries\_cloudagent.core.in\_memory package
=========================================

.. automodule:: aries_cloudagent.core.in_memory
   :members:
   :undoc-members:
   :show-inheritance:

Subpackages
-----------

.. toctree::
   :maxdepth: 4

   aries_cloudagent.core.in_memory.didcomm

Submodules
----------

aries\_cloudagent.core.in\_memory.profile module
------------------------------------------------

.. automodule:: aries_cloudagent.core.in_memory.profile
   :members:
   :undoc-members:
   :show-inheritance:
