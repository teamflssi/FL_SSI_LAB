# Issuing Indy Credentials

To be completed.